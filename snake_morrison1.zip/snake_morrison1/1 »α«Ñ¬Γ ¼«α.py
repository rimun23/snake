import pygame
import random

pygame.init()

WIDTH = 1000
HEIGHT = 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Змейка")

food_img = pygame.image.load('images/pngegg (5).png')
food_img = pygame.transform.scale(food_img, (20, 20))
snake_block = 10
snake_speed = 20

snake_hiss_sound = pygame.mixer.Sound('sounds/змея шипит.mp3')
collision_sound = pygame.mixer.Sound('sounds/удар.mp3')
apple_sound = pygame.mixer.Sound('sounds/яблочко.mp3')

font_style = pygame.font.Font('fonts/Roboto-BlackItalic.ttf', 24)
score_font = pygame.font.SysFont("comicsansms", 35)


def our_snake(snake_block, snake_list):
    for i in snake_list:
        pygame.draw.rect(screen, 'blue', [i[0], i[1], snake_block, snake_block])


def display_score(score):
    score_text = score_font.render("Очки: " + str(score), True, 'red')
    screen.blit(score_text, [10, 10])


def display_message(msg, color):
    message_text = font_style.render(msg, True, color)
    screen.blit(message_text, [WIDTH / 10, HEIGHT / 2])


def game_loop():
    game_over = False
    game_close = False
    x1 = WIDTH / 2
    y1 = HEIGHT / 2
    x1_change = 0
    y1_change = 0
    snake_list = []
    snake_length = 1
    foodx = random.randint(0, WIDTH - 20)
    foody = random.randint(0, HEIGHT - 20)
    while not game_over:
        while game_close == True:
            screen.fill('white')
            display_message("Вы проиграли, если хотите начать игру нажмите Q, если закрыть игру E", 'black')
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        snake_hiss_sound.play()
                        game_loop()
                    elif event.key == pygame.K_e:
                        game_over = True
                        game_close = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT and x1_change == 0:
                    x1_change = -snake_block
                    y1_change = 0
                elif event.key == pygame.K_RIGHT and x1_change == 0:
                    x1_change = snake_block
                    y1_change = 0
                elif event.key == pygame.K_UP and y1_change == 0:
                    y1_change = -snake_block
                    x1_change = 0
                elif event.key == pygame.K_DOWN and y1_change == 0:
                    y1_change = snake_block
                    x1_change = 0

        if x1 >= WIDTH or x1 < 0 or y1 >= HEIGHT or y1 < 0:
            collision_sound.play()
            game_close = True

        x1 += x1_change
        y1 += y1_change

        screen.fill('dark green')

        screen.blit(food_img, (foodx, foody))

        our_snake(snake_block, snake_list)

        snake_head = [x1, y1]
        snake_list.append(snake_head)

        if len(snake_list) > snake_length:
            del snake_list[0]

        for segment in snake_list[:-1]:
            if segment == snake_head:
                game_close = True
                collision_sound.play()

        if pygame.Rect(x1, y1, snake_block, snake_block).colliderect(pygame.Rect(foodx, foody, 20, 20)):
            foodx = random.randint(0, WIDTH - 20)
            foody = random.randint(0, HEIGHT - 20)
            snake_length += 5
            apple_sound.play()

        display_score(snake_length - 1)

        pygame.display.update()

        pygame.time.Clock().tick(snake_speed)

    pygame.quit()
    quit()


game_loop()
